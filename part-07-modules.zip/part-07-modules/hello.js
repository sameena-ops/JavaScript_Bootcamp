export let user ="Sameena !!"
export let user1 ="Sameena1 !!"

export let usergrp=[`sam`,`sam1`]